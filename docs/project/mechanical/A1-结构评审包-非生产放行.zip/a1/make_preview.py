"""从实际CAD三角面生成装配预览和完全离线的旋转/分解查看器。"""

from pathlib import Path
import json
import math
import numpy as np
from PIL import Image, ImageDraw, ImageFont
import vtk
from vtk.util.numpy_support import numpy_to_vtk, vtk_to_numpy

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "output"
MESHES = json.loads((OUT / "preview_meshes.json").read_text(encoding="utf-8"))


def explode_offset(part):
    # 分解位移仅用于展示装配关系，不能当作实际拆装路径分析。
    name, side = part["name"], part["side"]
    if "screen" in name:
        return np.array([0, 40 if "clamp" not in name else 15, 22])
    if name == "electronics_deck" or part["kind"]=="envelope":
        return np.array([0, 0, 32])
    if part["group"]=="foot":
        return np.array([side*20, 0, -12])
    if part["group"]=="leg":
        return np.array([side*20, 0, 0])
    return np.zeros(3)


def draw_panel(image, area, azimuth, elevation, exploded=False):
    # 使用真正的深度缓冲渲染，避免二维画家算法在孔洞和共面边缘产生假干涉。
    x0, y0, w, h = area
    renderer = vtk.vtkRenderer()
    renderer.SetBackground(245/255, 247/255, 251/255)
    for part in MESHES:
        verts = np.array(part["vertices"], dtype=float)
        if exploded:
            verts += explode_offset(part)
        points = vtk.vtkPoints()
        points.SetData(numpy_to_vtk(verts, deep=True))
        faces = vtk.vtkCellArray()
        for tri in part["faces"]:
            faces.InsertNextCell(3)
            for idx in tri:
                faces.InsertCellPoint(idx)
        poly = vtk.vtkPolyData()
        poly.SetPoints(points)
        poly.SetPolys(faces)
        normals = vtk.vtkPolyDataNormals()
        normals.SetInputData(poly)
        normals.ConsistencyOn()
        normals.Update()
        mapper = vtk.vtkPolyDataMapper()
        mapper.SetInputConnection(normals.GetOutputPort())
        actor = vtk.vtkActor()
        actor.SetMapper(mapper)
        rgb = [int(part["color"][k:k+2], 16)/255 for k in (1, 3, 5)]
        actor.GetProperty().SetColor(*rgb)
        actor.GetProperty().SetAmbient(0.32)
        actor.GetProperty().SetDiffuse(0.68)
        renderer.AddActor(actor)
    camera = renderer.GetActiveCamera()
    az, el = math.radians(azimuth), math.radians(elevation)
    center_z = 78 if exploded else 70
    camera.SetPosition(350*math.sin(az)*math.cos(el),
                       350*math.cos(az)*math.cos(el), center_z+350*math.sin(el))
    camera.SetFocalPoint(0, 0, center_z)
    camera.SetViewUp(0, 0, 1)
    camera.ParallelProjectionOn()
    camera.SetParallelScale(108 if exploded else 88)
    renderer.ResetCameraClippingRange()
    window = vtk.vtkRenderWindow()
    window.SetOffScreenRendering(1)
    window.SetSize(w, h)
    window.SetMultiSamples(4)
    window.AddRenderer(renderer)
    window.Render()
    capture = vtk.vtkWindowToImageFilter()
    capture.SetInput(window)
    capture.ReadFrontBufferOff()
    capture.Update()
    pixels = vtk_to_numpy(capture.GetOutput().GetPointData().GetScalars()).reshape(h, w, -1)
    image.paste(Image.fromarray(np.flipud(pixels).astype(np.uint8)).convert("RGB"), (x0, y0))
    window.Finalize()


def draw_panel_software(image, area, azimuth, elevation, exploded=False):
    x0, y0, w, h = area
    az, el = math.radians(azimuth), math.radians(elevation)
    view = np.array([math.sin(az)*math.cos(el), math.cos(az)*math.cos(el), math.sin(el)])
    right = np.array([math.cos(az), -math.sin(az), 0])
    up = np.cross(right, view)
    # 相机右向与上向组成正交投影，正Y为机器人的正面。
    projected, triangles = [], []
    for part in MESHES:
        verts = np.array(part["vertices"])
        if exploded:
            verts = verts+explode_offset(part)
        points = np.column_stack([verts@right, verts@up, verts@view])
        projected.append(points)
    all_points = np.vstack(projected)
    lo, hi = all_points[:, :2].min(axis=0), all_points[:, :2].max(axis=0)
    scale = min((w-50)/(hi[0]-lo[0]), (h-50)/(hi[1]-lo[1]))
    center = (lo+hi)/2
    light = np.array([0.4, 0.6, 1.0]); light /= np.linalg.norm(light)
    for part, points in zip(MESHES, projected):
        verts = np.array(part["vertices"])
        base = np.array([int(part["color"][k:k+2], 16) for k in (1, 3, 5)])
        for face in part["faces"]:
            p = points[face]
            vv = verts[face]
            normal = np.cross(vv[1]-vv[0], vv[2]-vv[0])
            norm = np.linalg.norm(normal)
            if norm<1e-9:
                continue
            shade = 0.65+0.35*abs(np.dot(normal/norm, light))
            color = tuple(np.minimum(255, base*shade).astype(int))
            xy = [(x0+w/2+(v[0]-center[0])*scale,
                   y0+h/2-(v[1]-center[1])*scale) for v in p]
            triangles.append((float(p[:, 2].mean()), xy, color))
    draw = ImageDraw.Draw(image)
    for _, points, color in sorted(triangles, key=lambda v:v[0]):
        draw.polygon(points, fill=color)


def main():
    img = Image.new("RGB", (1800, 1160), "#f5f7fb")
    draw = ImageDraw.Draw(img)
    font = "C:/Windows/Fonts/msyh.ttc"
    title = ImageFont.truetype(font, 36)
    text = ImageFont.truetype(font, 23)
    small = ImageFont.truetype(font, 20)
    draw_panel(img, (20, 140, 880, 860), 32, 20)
    draw_panel(img, (900, 140, 880, 860), 32, 20, True)
    draw = ImageDraw.Draw(img)
    draw.text((48, 25), "A1 参数化机械样机｜装配与分解", font=title, fill="#22354a")
    draw.text((48, 80), "来自真实STEP实体；安装接口尚待选定SKU/试件校准，禁止整套直接投产", font=text, fill="#98602f")
    draw.text((340, 1010), "装配视图", font=text, fill="#22354a")
    draw.text((1260, 1010), "分解示意", font=text, fill="#22354a")
    draw.text((48, 1070), "蓝：打印框架　橙：脚底叉架　灰：舵机　白：等效摇臂　绿：电子件占位", font=small, fill="#526079")
    draw.text((48, 1110), "分解方向仅为展示；实物行程、线束、承重、打印公差和慢走能力均须样机验证。", font=small, fill="#526079")
    img.save(OUT / "assembly_preview.png")
    template = (ROOT / "viewer_template.html").read_text(encoding="utf-8")
    template = template.replace("/*__MESH_DATA__*/[]", json.dumps(MESHES, ensure_ascii=False, separators=(",", ":")))
    (OUT / "装配查看器.html").write_text(template, encoding="utf-8")
    print("已生成装配预览与离线查看器")


if __name__ == "__main__":
    main()
