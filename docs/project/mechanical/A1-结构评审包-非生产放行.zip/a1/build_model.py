"""生成参数化工程样机、STEP/STL、装配预览与几何检查报告；不认证实物适配。"""

from pathlib import Path
import argparse
import itertools
import json
import math
import platform
import sys

import cadquery as cq
import numpy as np
import trimesh

ROOT = Path(__file__).resolve().parent
P = json.loads((ROOT / "parameters.json").read_text(encoding="utf-8"))
S, B, L, F, D = [P[k] for k in ("servo", "body", "leg", "foot", "screen")]
OUT = ROOT / "output"
PARTS = []


def box(x, y, z, cx=0, cy=0, cz=0):
    # 包围盒以中心定位，保持尺寸与装配坐标分离。
    return cq.Workplane("XY").box(x, y, z).translate((cx, cy, cz)).val()


def slab(x0, x1, y0, y1, z0, z1):
    return box(x1-x0, y1-y0, z1-z0, (x0+x1)/2, (y0+y1)/2, (z0+z1)/2)


def cylinder(r, length, start, direction=(0, 0, 1)):
    return cq.Solid.makeCylinder(r, length, cq.Vector(*start), cq.Vector(*direction))


def join(*items):
    result = items[0]
    for item in items[1:]:
        result = result.fuse(item)
    return result.clean()


def drill(shape, radius, start, length, direction=(0, 0, 1)):
    return shape.cut(cylinder(radius, length, start, direction)).clean()


def add(name, label, shape, color, kind="printed", group="body", side=0):
    PARTS.append(dict(name=name, label=label, shape=shape, color=color,
                      kind=kind, group=group, side=side))


def servo_local():
    # 局部原点为输出轴与舵机顶面的交点，输出轴朝局部正Z。
    a = S["axis_from_short_end"]
    body = slab(-a, S["body_length"]-a, -S["body_width"]/2,
                S["body_width"]/2, -S["body_depth"], 0)
    mid = S["mount_mid_x"]
    ears = slab(mid-S["ear_span"]/2, mid+S["ear_span"]/2,
                -S["body_width"]/2, S["body_width"]/2,
                S["ear_bottom"], S["ear_bottom"]+S["ear_thickness"])
    body = join(body, ears, cylinder(5.8, 2, (0, 0, 0)),
                cylinder(2.2, 3.5, (0, 0, 2)))
    for x in (mid-S["mount_pitch"]/2, mid+S["mount_pitch"]/2):
        body = drill(body, S["mount_hole"]/2, (x, 0, -9), 6)
    return body


def horn_local():
    # 这是等效传力圆盘占位；真实随附摇臂必须另行测量，不打印花键。
    horn = cylinder(S["horn_radius"], S["horn_thickness"],
                    (0, 0, S["horn_bottom"]))
    horn = drill(horn, 1.1, (0, 0, 3), 6)
    for x in (-S["horn_hole_radius"], S["horn_hole_radius"]):
        horn = drill(horn, 1.1, (x, 0, 3), 6)
    return horn


def hip_transform(shape, x):
    return shape.rotate((0, 0, 0), (1, 0, 0), 180).rotate(
        (0, 0, 0), (0, 0, 1), 90).translate((x, 0, B["hip_face_z"]))


def ankle_transform(shape, x):
    return shape.rotate((0, 0, 0), (0, 0, 1), 90).rotate(
        (0, 0, 0), (1, 0, 0), -90).translate(
        (x, L["ankle_face_y"], L["ankle_z"]))


def make_chassis():
    z = B["plate_z"]
    part = box(B["width"], B["depth"], B["plate_thickness"], cz=z+1.5)
    # 安装耳搭在底板上，舵机本体从上方穿过窗口。
    for x in (-B["hip_half_span"], B["hip_half_span"]):
        part = part.cut(box(S["body_width"]+2*S["clearance_each_side"],
                             S["body_length"]+2*S["clearance_each_side"],
                             10, x, S["body_length"]/2-S["axis_from_short_end"], z))
        for y in (S["mount_mid_x"]-S["mount_pitch"]/2,
                  S["mount_mid_x"]+S["mount_pitch"]/2):
            part = drill(part, S["mount_hole"]/2, (x, y, z-2), 10)
    for x0, x1, y0, y1 in ((-10, 10, -21, 21), (-20, 20, 22, 29), (-20, 20, -29, -22)):
        part = part.cut(slab(x0, x1, y0, y1, z-1, z+6))
    for x, y in itertools.product((-38, 38), (-26, 26)):
        post = cylinder(3.7, B["deck_z"]-z, (x, y, z))
        part = part.fuse(post)
        part = drill(part, 1.7, (x, y, z-1), B["deck_z"]-z+3)
    add("chassis", "机身舵机底架及立柱", part.clean(), "#547c9e")


def make_deck():
    z = B["deck_z"]
    part = box(B["width"], B["depth"], B["deck_thickness"], cz=z+B["deck_thickness"]/2)
    for x, y in itertools.product((-38, 38), (-26, 26)):
        part = drill(part, 1.7, (x, y, z-1), 6)
    # 开发板不假设存在安装孔，使用两端扎带槽与绝缘垫固定。
    for x in (-34, 34):
        part = part.cut(box(2.6, 8, 8, x, -17, z))
    for x in (-17, 17):
        part = part.cut(box(2.6, 10, 8, x, 12, z))
    for x in (-25, 25):
        part = drill(part, 1.7, (x, 24, z-1), 7)
    # 小模块可用独立扎带孔固定；不把未知模块焊孔冒充安装孔。
    for x in (-10, 10):
        part = part.cut(box(3, 6, 8, x, -1, z))
    for x in (-20, 0, 20):
        part = part.cut(box(12, 16, 8, x, -17, z))
    for x in (-8, 8):
        part = part.cut(box(9, 14, 8, x, 15, z))
    add("electronics_deck", "可拆电子平台", part.clean(), "#a6c8bc")


def make_leg(side):
    x = side*L["ankle_half_span"]
    hx = side*B["hip_half_span"]
    # 单独的髋转接片先锁摇臂中心螺丝，再从两侧可达孔装腿框。
    # 避免中心螺丝正下方被脚舵机挡住，造成模型可看但无法装配。
    attach_x = [hx-side*12, x+side*14]
    beam_min, beam_max = min(attach_x)-3, max(attach_x)+3
    part = join(slab(beam_min, beam_max, -5, 5,
                     L["top_z"], L["top_z"]+L["top_thickness"]),
                slab(x-11, x+11, -25, 5,
                     L["top_z"], L["top_z"]+L["top_thickness"]))
    dz = L["ankle_z"]-27
    part = join(part, slab(x-11, x+11, -25, -21, 7+dz, L["top_z"]+1),
                slab(x-11, x+11, -2, 1, 4+dz, 40+dz),
                slab(x-11, x-8, -25, 1, 7+dz, 41+dz),
                slab(x+8, x+11, -25, 1, 7+dz, 41+dz))
    # 前安装框的窗口与孔距由舵机局部基准映射，未实物确认前不可批量打印。
    cx = x
    zmid = L["ankle_z"]-(S["body_length"]/2-S["axis_from_short_end"])
    part = part.cut(box(S["body_width"]+2*S["clearance_each_side"], 8,
                         S["body_length"]+2*S["clearance_each_side"], cx, 0, zmid))
    for localx in (S["mount_mid_x"]-S["mount_pitch"]/2,
                   S["mount_mid_x"]+S["mount_pitch"]/2):
        part = drill(part, S["mount_hole"]/2,
                     (x, -4, L["ankle_z"]-localx), 9, (0, 1, 0))
    part = drill(part, 1.7, (x, -27, L["ankle_z"]), 9, (0, 1, 0))
    # 背板内侧留M3螺母位；侧面开放，允许先放螺母后装舵机。
    nut = cq.Workplane("XZ").polygon(6, P["fasteners"]["m3_nut_pocket_circumscribed_diameter"]).extrude(2.5).val()
    # XZ工作平面法向为负Y，螺母槽从背板内表面朝后切入。
    part = part.cut(nut.translate((x, -21, L["ankle_z"])))
    part = drill(part, 3.4, (hx, 0, L["top_z"]-1), 7)
    for xx in attach_x:
        part = drill(part, 1.15, (xx, 0, L["top_z"]-1), 10)
    # 背板减重槽避开轴线和顶部连接区。
    for zz in (14, 46):
        part = part.cut(box(9, 8, 7, x, -23, zz))
    for xx in (x-9.5, x+9.5):
        part = part.cut(box(6, 14, 19, xx, -12, 23))
    add(f"leg_{side}", "右腿连接框" if side>0 else "左腿连接框",
        part.clean(), "#7f9fc5", group="leg", side=side)
    adapter_z = L["top_z"]+L["top_thickness"]
    adapter = join(cylinder(P["fasteners"]["hip_adapter_radius"], 4, (hx, 0, adapter_z)),
                   slab(beam_min, beam_max, -4, 4, adapter_z, adapter_z+4))
    adapter = drill(adapter, 3.4, (hx, 0, adapter_z-1), 7)
    for yy in (-S["horn_hole_radius"], S["horn_hole_radius"]):
        adapter = drill(adapter, 1.15, (hx, yy, adapter_z-1), 7)
        # 摇臂紧固螺母从底面嵌入，避免突出后挡住下面的腿框。
        nut = cq.Workplane("XY").polygon(6, P["fasteners"]["m2_nut_pocket_circumscribed_diameter"]).extrude(1.8).val()
        adapter = adapter.cut(nut.translate((hx, yy, adapter_z)))
    for xx in attach_x:
        adapter = drill(adapter, 1.15, (xx, 0, adapter_z-1), 7)
        nut = cq.Workplane("XY").polygon(6, P["fasteners"]["m2_nut_pocket_circumscribed_diameter"]).extrude(1.8).val()
        adapter = adapter.cut(nut.translate((xx, 0, adapter_z+2.2)))
    add(f"hip_adapter_{side}", "可拆髋关节转接片", adapter.clean(),
        "#8dabc7", group="leg", side=side)


def make_foot(side):
    x = side*L["ankle_half_span"]
    part = box(F["width"], F["length"], F["sole_thickness"], x, 0, F["sole_thickness"]/2)
    part = join(part,
                slab(x-12, x+12, F["front_wall_y"], F["front_wall_y"]+3,
                     0, F["front_wall_height"]),
                slab(x-12, x+12, F["rear_wall_y"], F["rear_wall_y"]+3,
                     0, F["rear_wall_height"]))
    # 四个三角肋让侧板载荷传入脚底，不用一片薄壁单独承受弯矩。
    for xx in (x-12, x+9):
        # 后轴附近保留完整转动空间；后墙不向舵机框内添加三角肋。
        for yy, sign in ((15, -1),):
            rib = cq.Workplane("YZ").polyline(
                [(yy, 3), (yy+sign*9, 3), (yy, 18)]).close().extrude(3).val()
            part = part.fuse(rib.translate((xx, 0, 0)))
    part = drill(part, 3.4, (x, 13, L["ankle_z"]), 8, (0, 1, 0))
    for zz in (L["ankle_z"]-S["horn_hole_radius"],
               L["ankle_z"]+S["horn_hole_radius"]):
        part = drill(part, 1.1, (x, 13, zz), 8, (0, 1, 0))
    part = drill(part, F["bushing_hole"]/2,
                 (x, F["rear_wall_y"]-1, L["ankle_z"]), 6, (0, 1, 0))
    # 脚底开小减重槽，保留前后壁下方的完整承力材料。
    for xx in (x-16, x+16):
        part = part.cut(box(5, 22, 8, xx, -1, 2))
    add(f"foot_{side}", "右脚底及前后叉架" if side>0 else "左脚底及前后叉架",
        part.clean(), "#e5ad6c", group="foot", side=side)
    sleeve = cylinder(F["bushing_outer"]/2, F["bushing_sleeve_length"],
                      (x, -30.3, L["ankle_z"]), (0, 1, 0))
    flange = cylinder(4, F["bushing_flange_length"],
                      (x, -26.7, L["ankle_z"]), (0, 1, 0))
    sleeve = drill(join(sleeve, flange), F["bushing_bore"]/2,
                   (x, -31, L["ankle_z"]), 8, (0, 1, 0))
    add(f"pivot_bushing_{side}", "脚关节带肩轴套", sleeve,
        "#e5d7ae", group="leg", side=side)


def make_face():
    cz = D["frame_bottom_z"]+D["frame_height"]/2
    fy = D["frame_front_y"]-D["frame_thickness"]
    frame = slab(-30, 30, fy, fy+3, cz-20, cz+20)
    frame = frame.cut(box(D["active_width_landscape"]+0.6, 8,
                           D["active_height_landscape"]+0.6, 0, fy+1, cz))
    for x in (-25, 25):
        frame = frame.fuse(slab(x-6, x+6, 18, 34,
                               B["deck_z"]+B["deck_thickness"], D["frame_bottom_z"]+0.1))
        frame = drill(frame, 1.7, (x, 24, 96), 10)
        for z in (cz-13, cz+13):
            frame = frame.fuse(box(6, 3.5, 6, x, 29.25, z))
            frame = drill(frame, 1.1, (x, 23, z), 12, (0, 1, 0))
        rib = cq.Workplane("YZ").polyline(
            [(20, D["frame_bottom_z"]), (31, D["frame_bottom_z"]),
             (31, D["frame_bottom_z"]+12)]).close().extrude(3).val()
        frame = frame.fuse(rib.translate((math.copysign(29.5, x)-1.5, 0, 0)))
        bar = box(9, 3, 34, math.copysign(22.5, x), 26, cz)
        for z in (cz-13, cz+13):
            bar = drill(bar, 1.1, (x, 23, z), 7, (0, 1, 0))
        add(f"screen_clamp_{int(x)}", "屏幕背面压条", bar, "#cbd8e4")
    add("screen_frame", "屏幕面框及底脚", frame.clean(), "#456880")
    pcb = box(D["pcb_width_landscape"], D["pcb_thickness_assumed"],
              D["pcb_height_landscape"], 0, 28.3, cz)
    add("screen_pcb", "彩屏PCB占位", pcb, "#23433f", "envelope")
    glass = box(D["active_width_landscape"], D["glass_depth_assumed"],
                D["active_height_landscape"], 0, 30.1, cz)
    add("screen_glass", "彩屏玻璃占位", glass, "#67d8c4", "envelope")


def make_references():
    for side in (-1, 1):
        hx = side*B["hip_half_span"]
        ax = side*L["ankle_half_span"]
        add(f"hip_servo_{side}", "腿关节舵机占位", hip_transform(servo_local(), hx),
            "#4d4e57", "purchased")
        add(f"hip_horn_{side}", "腿关节等效摇臂", hip_transform(horn_local(), hx),
            "#f0eee4", "reference", "leg", side)
        add(f"ankle_servo_{side}", "脚关节舵机占位", ankle_transform(servo_local(), ax),
            "#4d4e57", "purchased", "leg", side)
        add(f"ankle_horn_{side}", "脚关节等效摇臂", ankle_transform(horn_local(), ax),
            "#f0eee4", "reference", "foot", side)
    dims = P["electronics_envelopes"]["board"]
    add("esp32_envelope", "开发板含排针占位", box(*dims, cy=-17, cz=105.6),
        "#36785d", "envelope")
    env = P["electronics_envelopes"]
    add("speaker_envelope", "扬声器占位", cylinder(env["speaker_diameter_assumed"]/2,
        env["speaker_height_assumed"], (0, 12, 99.6)), "#555a61", "envelope")
    # 音频小板包络仅用于预留空间，实物尺寸未知，不进入打印孔位。
    add("mic_envelope", "麦克风预留空间", box(14, 14, 5, -30, 7, 104),
        "#548d72", "envelope")
    add("amp_envelope", "功放预留空间", box(14, 14, 5, 30, 7, 112),
        "#548d72", "envelope")


def make_coupons():
    # 三种单边间隙的本体窗口试片，避免直接用理论尺寸打印整套。
    for gap in (0.2, 0.35, 0.5):
        plate = box(40, 22, 3, cz=1.5)
        plate = plate.cut(box(S["body_length"]+2*gap,
                               S["body_width"]+2*gap, 7, cz=1.5))
        for xx in (-S["mount_pitch"]/2, S["mount_pitch"]/2):
            plate = drill(plate, S["mount_hole"]/2, (xx, 0, -1), 6)
        # 缺口数量与间隙对应，试片不用依赖字体生成细小文字。
        for k in range((0.2, 0.35, 0.5).index(gap)+1):
            plate = plate.cut(box(1, 2, 7, -16+k*2, 10.5, 1.5))
        path = OUT / "fit_coupons" / f"servo_window_gap_{gap:.2f}"
        path.parent.mkdir(parents=True, exist_ok=True)
        cq.exporters.export(plate, str(path)+".step")
        cq.exporters.export(plate, str(path)+".stl", tolerance=0.05, angularTolerance=0.1)
    # 额外的螺母与轴套孔试条，用于核对打印设备，不代替舵机实物尺寸。
    coupon = box(80, 20, 4, cz=2)
    for xx, diam in ((-12, 5.2), (0, 5.4), (12, 5.6)):
        coupon = drill(coupon, diam/2, (xx, 0, -1), 7)
    for xx, key, depth, bore in ((-30, "m2_nut_pocket_circumscribed_diameter", 1.8, 2.3),
                                 (30, "m3_nut_pocket_circumscribed_diameter", 2.5, 3.4)):
        pocket = cq.Workplane("XY").polygon(6, P["fasteners"][key]).extrude(depth+1).val()
        coupon = coupon.cut(pocket.translate((xx, 0, 4-depth)))
        coupon = drill(coupon, bore/2, (xx, 0, -1), 7)
    # M2端只开一个边缘识别缺口，便于判断从左到右的孔序。
    coupon = coupon.cut(box(2, 3, 8, -37, 9.5, 2))
    path = OUT / "fit_coupons" / "nut_and_pivot_clearance"
    cq.exporters.export(coupon, str(path)+".step")
    cq.exporters.export(coupon, str(path)+".stl", tolerance=0.05, angularTolerance=0.1)


def pose_shape(item, hip, ankle):
    shape = item["shape"]
    side = item["side"]
    if item["group"] == "foot":
        pivot = (side*L["ankle_half_span"], L["ankle_face_y"], L["ankle_z"])
        shape = shape.rotate(pivot, (pivot[0], pivot[1]+1, pivot[2]), ankle)
    if item["group"] in ("leg", "foot"):
        pivot = (side*B["hip_half_span"], 0, B["hip_pivot_z"])
        shape = shape.rotate(pivot, (pivot[0], pivot[1], pivot[2]+1), hip)
    return shape


def collision_scan():
    # 包围盒先筛选，再用精确实体求交；接触面和预期花键接口不按干涉计。
    cases = [(0, 0, 0, 0), (10, -10, 0, 0), (-10, 10, 0, 0),
             (0, 0, 10, 10), (0, 0, -10, -10),
             (10, 10, 10, -10), (-10, -10, -10, 10),
             (10, -10, 10, -10), (-10, 10, -10, 10)]
    cases += list(itertools.product((-15, 15), repeat=4))
    results = []
    for hl, hr, al, ar in cases:
        shapes = [(p, pose_shape(p, hl if p["side"]<0 else hr,
                                    al if p["side"]<0 else ar)) for p in PARTS]
        collisions = []
        for (p, a), (q, b) in itertools.combinations(shapes, 2):
            # 同一刚体内部也检查，但舵机轴与等效摇臂的预期嵌合单独声明。
            expected = any({p["name"], q["name"]} == {f"{joint}_servo_{s}", f"{joint}_horn_{s}"}
                           for joint in ("hip", "ankle") for s in (-1, 1))
            if expected:
                continue
            ba, bb = a.BoundingBox(), b.BoundingBox()
            if any(min(getattr(ba, f"{v}max"), getattr(bb, f"{v}max"))-
                   max(getattr(ba, f"{v}min"), getattr(bb, f"{v}min")) < 1e-5
                   for v in "xyz"):
                continue
            volume = a.intersect(b).Volume()
            if volume > 0.02:
                collisions.append(dict(parts=[p["name"], q["name"]], volume_mm3=round(volume, 4)))
        results.append(dict(angles_deg=[hl, hr, al, ar], collisions=collisions))
    return results


def export_all(skip_scan=False):
    OUT.mkdir(exist_ok=True)
    assembly = cq.Assembly(name="desktop_robot_A1")
    meshes, manifest = [], []
    for item in PARTS:
        name, shape = item["name"], item["shape"]
        if not shape.isValid() or len(shape.Solids()) != 1:
            raise RuntimeError(f"零件无效或不是单一实体：{name}，实体数={len(shape.Solids())}")
        color = tuple(int(item["color"][i:i+2], 16)/255 for i in (1, 3, 5))
        assembly.add(shape, name=name, color=cq.Color(*color))
        verts, faces = shape.tessellate(0.12, 0.18)
        vertices = np.array([v.toTuple() for v in verts])
        faces = np.array(faces)
        mesh = trimesh.Trimesh(vertices=vertices, faces=faces, process=True)
        mesh.visual.vertex_colors = [int(v*255) for v in color]+[255]
        meshes.append((name, mesh))
        bounds = shape.BoundingBox()
        rec = {k:v for k,v in item.items() if k!="shape"}
        rec.update(volume_mm3=round(shape.Volume(), 3), valid=True, solid_count=1,
                   stl_watertight=bool(mesh.is_watertight),
                   bounds_mm=[[round(bounds.xmin,3),round(bounds.ymin,3),round(bounds.zmin,3)],
                              [round(bounds.xmax,3),round(bounds.ymax,3),round(bounds.zmax,3)]])
        if item["kind"] == "printed":
            folder = OUT / "parts_nominal"
            folder.mkdir(exist_ok=True)
            cq.exporters.export(shape, str(folder / f"{name}.step"))
            # 独立STL移到正坐标原点附近，单位毫米；装配STEP保留全局坐标。
            local = shape.translate((-bounds.xmin, -bounds.ymin, -bounds.zmin))
            cq.exporters.export(local, str(folder / f"{name}.stl"), tolerance=0.05, angularTolerance=0.1)
            rec["stl_translation_mm"] = [-bounds.xmin, -bounds.ymin, -bounds.zmin]
        manifest.append(rec)
    assembly.export(str(OUT / "robot_A1_assembly.step"))
    scene = trimesh.Scene()
    for name, mesh in meshes:
        scene.add_geometry(mesh, node_name=name, geom_name=name)
    # glTF标准以米为单位；STEP、STL及本地查看器仍保持毫米。
    glb_scene = scene.copy()
    glb_scene.apply_scale(0.001)
    glb_scene.export(str(OUT / "robot_A1_preview.glb"))
    make_coupons()
    scan = [] if skip_scan else collision_scan()
    volume = sum(m["volume_mm3"] for m in manifest if m["kind"]=="printed")
    report = dict(revision=P["revision"], python=platform.python_version(), cadquery=cq.__version__,
                  units="mm", parts=manifest,
                  printed_solid_volume_cm3=round(volume/1000, 3),
                  printed_solid_mass_at_1_24_g_cm3=round(volume/1000*1.24, 2),
                  mass_note="体积×密度仅为模型全实体参考质量；切片壳层、填充、支撑和材料密度会改变重量。",
                  sampled_pose_checks=scan,
                  scan_limit="有限离散姿态求交，非连续扫掠；未模拟线缆、真实摇臂、螺丝头、地面接触或稳定性。",
                  unverified=P["sources_and_limits"]["critical_unverified"])
    (OUT / "validation.json").write_text(json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8")
    # 保留三角面数据用于不依赖外部服务的本地预览。
    preview = []
    for item, (_, mesh) in zip(PARTS, meshes):
        preview.append(dict(name=item["name"], label=item["label"], color=item["color"],
                            group=item["group"], side=item["side"], kind=item["kind"],
                            vertices=np.round(mesh.vertices, 3).tolist(), faces=mesh.faces.tolist()))
    (OUT / "preview_meshes.json").write_text(json.dumps(preview, ensure_ascii=False, separators=(",", ":")), encoding="utf-8")
    print(json.dumps(dict(parts=len(manifest), printed=sum(m["kind"]=="printed" for m in manifest),
                          solid_mass_g=report["printed_solid_mass_at_1_24_g_cm3"],
                          poses=len(scan), collision_counts=[len(s["collisions"]) for s in scan]), ensure_ascii=False))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--skip-scan", action="store_true", help="首次调试可跳过耗时的姿态求交")
    args = parser.parse_args()
    make_chassis()
    make_deck()
    for side in (-1, 1):
        make_leg(side)
        make_foot(side)
    make_face()
    make_references()
    export_all(args.skip_scan)


if __name__ == "__main__":
    main()
