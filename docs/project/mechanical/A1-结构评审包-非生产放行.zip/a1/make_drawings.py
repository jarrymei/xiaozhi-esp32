"""从导出的STEP生成关键零件正投影视图及外包尺寸索引，供结构评审。"""

from pathlib import Path
import html
import json
import re
import cadquery as cq

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "output"


def main():
    report = json.loads((OUT / "validation.json").read_text(encoding="utf-8"))
    names = ["chassis", "electronics_deck", "hip_adapter_1", "leg_1",
             "foot_1", "pivot_bushing_1", "screen_frame", "screen_clamp_25"]
    items = {p["name"]:p for p in report["parts"]}
    elements = ['<svg xmlns="http://www.w3.org/2000/svg" width="1200" height="1900" viewBox="0 0 1200 1900">',
                '<rect width="1200" height="1900" fill="white"/>',
                '<g font-family="Microsoft YaHei,sans-serif" fill="#20314b">',
                '<text x="35" y="45" font-size="26">A1 关键零件正投影与尺寸索引</text>',
                '<text x="35" y="78" font-size="16">单位mm｜右侧腿脚示例，左侧见装配STEP｜标称接口待校准，非生产放行图</text>']
    for idx, name in enumerate(names):
        item = items[name]
        x, y = 25+(idx%2)*590, 110+(idx//2)*435
        elements.append(f'<text x="{x}" y="{y+23}" font-size="20">{idx+1}. {html.escape(item["label"])}</text>')
        shape = cq.importers.importStep(str(OUT / "parts_nominal" / f"{name}.step")).val()
        for k, projection in enumerate(((0, 1, 0), (1, 0, 0))):
            svg = cq.Workplane(obj=shape).toSvg(dict(width=270, height=290,
                marginLeft=15, marginTop=15, projectionDir=projection,
                showHidden=False, showAxes=False, strokeWidth=0.45,
                strokeColor=(35, 50, 70)))
            svg = re.sub(r'^.*?<svg\b', '<svg', svg, flags=re.S)
            # 内嵌独立投影视口，不通过截图缩放或手绘近似零件边线。
            svg = svg.replace('<svg ', f'<svg x="{x+k*280}" y="{y+35}" ', 1)
            elements.append(svg)
            elements.append(f'<text x="{x+75+k*280}" y="{y+350}" font-size="14">{"沿Y看正面" if k==0 else "沿X看侧面"}</text>')
        dims = [round(b-a, 2) for a,b in zip(*item["bounds_mm"])]
        elements.append(f'<text x="{x}" y="{y+383}" font-size="16">外包 X×Y×Z：{dims[0]} × {dims[1]} × {dims[2]}</text>')
        elements.append(f'<text x="{x}" y="{y+410}" font-size="13">零件名：{html.escape(name)}；孔位基准见README与parameters.json</text>')
    elements.append('<text x="35" y="1880" font-size="14">边线来自CAD实体；装配关系用STEP核对。本图未给出所有制造公差、螺纹和表面要求。</text></g></svg>')
    (OUT / "零件正投影与尺寸索引.svg").write_text("\n".join(elements), encoding="utf-8")
    print("已生成关键零件正投影索引")


if __name__ == "__main__":
    main()
