"""回读实际导出文件，核对闭合性、实体有效性、数量、体积和单位。"""

from pathlib import Path
import hashlib
import json
import cadquery as cq
import trimesh

ROOT = Path(__file__).resolve().parent
OUT = ROOT / "output"


def main():
    report = json.loads((OUT / "validation.json").read_text(encoding="utf-8"))
    checks = []
    for part in report["parts"]:
        if part["kind"] != "printed":
            continue
        base = OUT / "parts_nominal" / part["name"]
        step = cq.importers.importStep(str(base)+".step").val()
        mesh = trimesh.load(str(base)+".stl", force="mesh")
        relative_error = abs(mesh.volume-part["volume_mm3"])/part["volume_mm3"]
        ok = step.isValid() and len(step.Solids())==1 and mesh.is_watertight and relative_error<0.01
        checks.append(dict(name=part["name"], step_valid=step.isValid(),
                           stl_watertight=bool(mesh.is_watertight),
                           stl_volume_relative_error=round(float(relative_error),6), passed=bool(ok)))
    coupons = []
    for path in sorted((OUT / "fit_coupons").glob("*.stl")):
        mesh = trimesh.load(path, force="mesh")
        coupons.append(dict(file=path.name, watertight=bool(mesh.is_watertight)))
    assembly = cq.importers.importStep(str(OUT / "robot_A1_assembly.step")).val()
    scene = trimesh.load_scene(OUT / "robot_A1_preview.glb")
    dimensions = (scene.bounds[1]-scene.bounds[0]).tolist()
    assembly_ok = assembly.isValid() and len(assembly.Solids())==len(report["parts"])
    # GLB按米导出，尺寸与毫米STEP比值应为千分之一。
    step_box = assembly.BoundingBox()
    reference = [step_box.xlen, step_box.ylen, step_box.zlen]
    glb_units_ok = all(abs(a*1000-b)<0.1 for a,b in zip(dimensions,reference))
    file_hashes = {}
    for path in sorted(OUT.rglob("*")):
        if path.is_file() and path.suffix in (".step", ".stl", ".glb"):
            file_hashes[str(path.relative_to(OUT))] = hashlib.sha256(path.read_bytes()).hexdigest()
    passed = all(c["passed"] for c in checks) and all(c["watertight"] for c in coupons) and assembly_ok and glb_units_ok
    result = dict(geometry_export_checks_passed=passed, part_checks=checks,
                  coupons=coupons, assembly_step_valid=assembly.isValid(),
                  assembly_solid_count=len(assembly.Solids()), assembly_bounds_mm=reference,
                  glb_bounds_m=dimensions, glb_unit_check_passed=glb_units_ok, sha256=file_hashes,
                  limitation="只验证导出的几何文件，不认证实物尺寸、强度、打印配合或步行稳定性。")
    (OUT / "export_verification.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(dict(passed=passed, parts=len(checks), coupons=len(coupons),
                          assembly_solids=len(assembly.Solids()), dimensions_mm=reference)))
    if not passed:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
